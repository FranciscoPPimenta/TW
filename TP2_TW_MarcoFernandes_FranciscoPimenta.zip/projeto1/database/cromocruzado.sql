-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2024 at 02:13 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cromocruzado`
--
CREATE DATABASE IF NOT EXISTS `cromocruzado` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cromocruzado`;

-- --------------------------------------------------------

--
-- Table structure for table `carrinho`
--

DROP TABLE IF EXISTS `carrinho`;
CREATE TABLE IF NOT EXISTS `carrinho` (
  `id_carrinho` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `sticker` int(11) NOT NULL,
  `quantia` int(11) NOT NULL,
  PRIMARY KEY (`id_carrinho`),
  KEY `user` (`user`),
  KEY `sticker` (`sticker`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carrinho`
--

INSERT INTO `carrinho` (`id_carrinho`, `user`, `sticker`, `quantia`) VALUES
(14, 15, 2, 1),
(15, 15, 2, 1),
(16, 15, 2, 1),
(17, 15, 2, 1),
(18, 15, 2, 1),
(19, 15, 2, 1),
(20, 15, 2, 1),
(21, 15, 2, 1),
(22, 15, 2, 1),
(23, 15, 2, 1),
(24, 15, 2, 1),
(25, 15, 2, 1),
(26, 15, 2, 1),
(27, 15, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
CREATE TABLE IF NOT EXISTS `history` (
  `id_userFrom` int(11) NOT NULL,
  `id_userTo` int(11) DEFAULT NULL,
  `id_sticker` int(11) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `dateTrade` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `FK_StickerHistory` (`id_sticker`),
  KEY `FK_UserToHistory` (`id_userTo`),
  KEY `FK_UserFromHistory` (`id_userFrom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id_userFrom`, `id_userTo`, `id_sticker`, `description`, `dateTrade`) VALUES
(15, NULL, NULL, 'O Utilizador <b>DunJun</b> entrou!', '2024-06-20 23:35:16'),
(9, NULL, NULL, 'O Administrador <b>Marco Fernandes</b> entrou!', '2024-06-20 23:51:17'),
(15, NULL, NULL, 'O Utilizador <b>DunJun</b> entrou!', '2024-06-20 23:52:13');

-- --------------------------------------------------------

--
-- Table structure for table `stickers`
--

DROP TABLE IF EXISTS `stickers`;
CREATE TABLE IF NOT EXISTS `stickers` (
  `id_sticker` int(11) NOT NULL AUTO_INCREMENT,
  `sticker_num` int(11) NOT NULL,
  `sticker_name` varchar(50) NOT NULL,
  `sticker_price` decimal(11,2) NOT NULL,
  `sticker_pic` varchar(50) NOT NULL,
  `descricao` text DEFAULT NULL,
  `country` int(11) NOT NULL,
  PRIMARY KEY (`id_sticker`),
  KEY `country` (`country`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stickers`
--

INSERT INTO `stickers` (`id_sticker`, `sticker_num`, `sticker_name`, `sticker_price`, `sticker_pic`, `descricao`, `country`) VALUES
(1, 1, 'Cristiano Ronaldo', 25.00, 'cristiano_ronaldo.png', 'Cristiano Ronaldo é um jogador de futebol português renomado pelas suas habilidades e conquistas,amplamente reconhecido pelo seu talento, dedicação e impacto global no futebol.<br><br>Idade: 39 anos<br><br>Clube atual: Al Nassr (Arábia Saudita)', 1),
(2, 2, 'Bruno Fernandes', 5.00, 'bruno_fernandes.png', 'Bruno Fernandes é um jogador de futebol português destacado, reconhecido pela sua habilidades de passe, visão de jogo e capacidade de marcar golo.\n<br><br>\nIdade: 29 anos (nascido em 8 de setembro de 1994)<br><br>\nClube atual: Manchester United (Inglaterra)<br><br>\nFernandes é uma peça fundamental tanto no seu clube quanto na seleção portuguesa, conhecido pela sua liderança em campo e precisão nas cobranças de penalti e faltas.', 1),
(3, 3, 'Bernardo Silva', 5.00, 'bernardo_silva.png', 'Bernardo Silva é um talentoso jogador de futebol português conhecido por sua habilidade técnica e versatilidade em campo, e é admirado por sua visão de jogo, controle de bola e capacidade de atuar em várias posições no meio-campo e no ataque.<br><br>Idade: 29 anos (nascido em 10 de agosto de 1994)<br><br>Clube atual: Manchester City (Inglaterra)', 1),
(4, 4, 'João Félix', 4.00, 'joao_felix.png', 'João Félix é um jogador de futebol português promissor , conhecido pela sua criatividade, velocidade e habilidade de drible.\n<br><br>\nIdade: 24 anos (nascido em 10 de novembro de 1999)<br>\nClube atual: Barcelona (Espanha), emprestado pelo Atlético de Madrid (Espanha)<br><br>\nFélix é elogiado pelo seu talento natural e potencial para se tornar um dos melhores atacantes do futebol mundial.', 1),
(5, 5, 'Rúben Dias', 5.00, 'ruben_dias.png', 'Rúben Dias é um sólido defensor português, reconhecido por sua liderança, força física e habilidade defensiva.\n<br><br>\nIdade: 27 anos (nascido em 14 de maio de 1997)<br><br>\nClube atual: Manchester City (Inglaterra)<br><br>\nDias é valorizado por sua capacidade de organizar a defesa, ler o jogo e contribuir para a saída de bola da equipe, sendo um pilar tanto no clube quanto na seleção portuguesa.', 1),
(6, 6, 'Diogo Jota', 4.00, 'diogo_jota.png', 'Diogo Jota é um talentoso atacante português, conhecido por sua versatilidade, velocidade e capacidade de finalização.\n<br><br>\nIdade: 27 anos (nascido em 4 de dezembro de 1996)<br><br>\nClube atual: Liverpool (Inglaterra)<br><br>\nJota é apreciado por sua habilidade de jogar em várias posições no ataque, seu trabalho árduo e sua eficácia em marcar gols, sendo uma peça importante tanto para seu clube quanto para a seleção portuguesa.', 1),
(7, 7, 'João Cancelo', 5.00, 'joao_cancelo.png', 'João Cancelo é um habilidoso jogador de futebol português, reconhecido por sua versatilidade, habilidade no ataque e solidez defensiva.\n<br><br>\nIdade: 30 anos (nascido em 27 de maio de 1994)<br><br>\nClube atual: Barcelona (Espanha), emprestado pelo Manchester City (Inglaterra)<br><br>\nCancelo é valorizado por sua capacidade de jogar em ambas as laterais, sua técnica apurada e sua contribuição tanto na defesa quanto no ataque, sendo um jogador chave tanto para seu clube quanto para a seleção portuguesa.', 1),
(8, 8, 'Rui Patrício', 4.00, 'rui_patricio.png', 'Rui Patrício é um experiente goleiro português, conhecido por suas defesas seguras e liderança no gol.\n<br><br>\nIdade: 36 anos (nascido em 15 de fevereiro de 1988)<br><br>\nClube atual: Roma (Itália)<br><br>\nPatrício é valorizado por sua consistência, reflexos rápidos e capacidade de comandar a defesa, sendo uma presença confiável tanto em seu clube quanto na seleção portuguesa.', 1),
(9, 9, 'Pepe', 4.00, 'pepe.png', 'Pepe é um veterano e renomado zagueiro português, conhecido por sua força, tenacidade e habilidades defensivas.\n<br><br>\nIdade: 41 anos (nascido em 26 de fevereiro de 1983)<br><br>\nClube atual: FC Porto (Portugal)<br><br>\nPepe é respeitado por sua vasta experiência, liderança em campo e capacidade de leitura do jogo, sendo uma figura central tanto no seu clube quanto na seleção portuguesa ao longo de muitos anos.', 1),
(10, 10, 'Francisco Conceição', 4.00, 'francisco_conceicao.png', 'Francisco Conceição é um jovem e promissor jogador de futebol português, conhecido por sua velocidade, habilidade de drible e criatividade no ataque.\n\nIdade: 21 anos (nascido em 14 de dezembro de 2002)\nClube atual: FC Porto (Portugal)\nConceição é apreciado por seu talento e potencial, sendo considerado uma das futuras estrelas do futebol português. Ele traz energia e inovação para o ataque de sua equipe.', 1),
(11, 11, 'João Neves', 4.00, 'joao_neves.png', 'João Neves é um jovem jogador de futebol português, reconhecido por sua habilidade técnica e inteligência tática no meio-campo.\n<br><br>\nIdade: 19 anos (nascido em 27 de setembro de 2004)<br><br>\nClube atual: Benfica (Portugal)<br><br>\nNeves é considerado um dos talentos emergentes do futebol português, elogiado por sua visão de jogo, passes precisos e capacidade de controlar o ritmo do jogo.', 1),
(12, 12, 'Kylian Mbappé', 0.50, 'kylianmbappe.png', 'Kylian Mbappé é um dos jogadores de futebol mais talentosos e rápidos do mundo, conhecido por sua velocidade explosiva, habilidade de drible e capacidade de marcar gols.\n<br><br>\nIdade: 25 anos (nascido em 20 de dezembro de 1998)<br><br>\nClube atual: Paris Saint-Germain (França)<br><br>\nMbappé é amplamente reconhecido por suas conquistas tanto no clube quanto na seleção francesa, incluindo a vitória na Copa do Mundo de 2018. Ele é considerado uma das estrelas mais brilhantes do futebol contemporâneo.', 2);

-- --------------------------------------------------------

--
-- Table structure for table `sticker_country`
--

DROP TABLE IF EXISTS `sticker_country`;
CREATE TABLE IF NOT EXISTS `sticker_country` (
  `id_country` int(11) NOT NULL,
  `country` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sticker_country`
--

INSERT INTO `sticker_country` (`id_country`, `country`) VALUES
(1, 'Portugal'),
(2, 'França'),
(3, 'Alemanha'),
(4, 'Croácia');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` int(11) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id_user`),
  KEY `FK_TypeUser` (`user_type`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `user_type`, `name`, `email`, `phone_number`, `profile_pic`, `description`, `password`) VALUES
(1, 0, 'Marco Fernandes', 'marco.fernandes@ipvc.pt', NULL, '', NULL, '$2y$10$oDXDYZuB1qTxKc7q9V433.2ML14g7fYDyErK1i5UsCW'),
(7, 0, 'teste teste', 'teste@gmail.com', NULL, NULL, NULL, '$2y$10$W7YaYrTUi29UIP3mO59XmOH7zVCqIyRKldrge4a6Kc'),
(9, 2, 'Marco Fernandes', 'marco@ipvc.pt', 30566, 'profile_marco.jpeg', 'Licenciatura de ECGM', '$2y$10$1TdKAsWJiwpnds9Yzdn0juTb6qwp6lKIgDJQUaO6nA3assMJTTWYS'),
(11, 0, 'Francisco Pimenta', 'franciscopimenta@ipvc.pt', NULL, NULL, NULL, '$2y$10$NdI3IpW95PbjJ4dUbYbeJe.nn5RupAiMHMd8NrBpuv/msn.ctzuay'),
(15, 0, 'DunJun', 'kikitopimenta123@gmail.com', NULL, 'https://lh3.googleusercontent.com/a/ACg8ocLKM9C0lnZ5RInTt3jH8Y1iBQsAP10TeFKxwcRe97CBrG1dhjkm=s96-c', NULL, '$2y$10$WY78a.7O6Ol6bxM/3AqCd.ubYJJIVL4OIrQqWbw.KgCq8PaLkEziS');

-- --------------------------------------------------------

--
-- Table structure for table `user_types`
--

DROP TABLE IF EXISTS `user_types`;
CREATE TABLE IF NOT EXISTS `user_types` (
  `id_type` int(11) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_types`
--

INSERT INTO `user_types` (`id_type`, `type`) VALUES
(0, 'Normal'),
(1, 'Moderador'),
(2, 'Fundador');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `carrinho`
--
ALTER TABLE `carrinho`
  ADD CONSTRAINT `carrinho_ibfk_1` FOREIGN KEY (`user`) REFERENCES `users` (`id_user`),
  ADD CONSTRAINT `carrinho_ibfk_2` FOREIGN KEY (`sticker`) REFERENCES `stickers` (`id_sticker`);

--
-- Constraints for table `stickers`
--
ALTER TABLE `stickers`
  ADD CONSTRAINT `stickers_ibfk_1` FOREIGN KEY (`country`) REFERENCES `sticker_country` (`id_country`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `FK_TypeUser` FOREIGN KEY (`user_type`) REFERENCES `user_types` (`id_type`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
