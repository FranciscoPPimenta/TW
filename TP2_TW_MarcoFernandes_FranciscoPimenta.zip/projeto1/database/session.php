<?php
// Initialize the session
session_start();

if (empty($_SESSION)) {
    header('location:login.php');
    exit;
}
