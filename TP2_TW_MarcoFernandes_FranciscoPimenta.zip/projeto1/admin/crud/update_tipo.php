<?php
require_once '../../database/session.php';
require '../../database/config.php';
 
// Define variables and initialize with empty values
$tipo = "";
 
// Processing form data when form is submitted
if(isset($_POST["id_type"]) && !empty($_POST["id_type"])){
    // Get hidden input value
    $id = $_POST["id_type"];
    
    // Validate tipo
    $input_tipo = $_POST["tipo"];
    if(empty($input_tipo)){
        $errors['login'] = "Introduza um tipo.";
    } else{
        $tipo = $input_tipo;
    }
    
    // Check input errors before inserting in database
    if(empty($errors['login'])){
        // Prepare an update statement
        $sql = "UPDATE user_types SET type=? WHERE id_type=?";
 
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("si", $param_tipo, $param_id);
            
            // Set parameters
            $param_tipo = $tipo;
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Records updated successfully. Redirect to landing page
                echo '<script> alert("Data Updated"); </script>';
                write_log( "Tipo atualizado! -> <b>" . $tipo . "</b>");
                header("location: ../type.php");
                // exit();
            } else{
                echo '<script> alert("Data Not Updated"); </script>';
            }
        }
         
        // Close statement
        $stmt->close();
    }
    
    // Close connection
    $mysqli->close();
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id_type"]) && !empty(trim($_GET["id_type"]))){
        // Get URL parameter
        $id =  trim($_GET["id_type"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM user_types WHERE id_type = ?";
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("i", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                $result = $stmt->get_result();
                
                if($result->num_rows == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $row = $result->fetch_array(MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $tipo = $row["type"];
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        $stmt->close();
        
        // Close connection
        $mysqli->close();
    } else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: ../blank.php");
        exit();
    }
}
?>
 
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Atualizar tipo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Atualizar tipo</h2>
                    <p>Por favor, atualize as informações e de seguida pressione o botão "ATUALIZAR".</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group">
                            <label>Tipo</label>
                            <input type="text" name="tipo" class="form-control <?php echo (!empty($errors)) ? 'is-invalid' : ''; ?>" value="<?php echo $tipo; ?>">
                            <span class="invalid-feedback"><?php echo $errors['login'];?></span>
                        </div>
                        <input type="hidden" name="id_type" value="<?php echo $id; ?>"/>
                        <input type="submit" class="btn btn-primary" value="ATUALIZAR">
                        <a href="../type.php" class="btn btn-secondary ml-2">CANCELAR</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>