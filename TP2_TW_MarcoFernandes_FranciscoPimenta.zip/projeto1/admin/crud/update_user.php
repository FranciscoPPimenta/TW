<?php

require_once '../../database/session.php';
require '../../database/config.php';

$id_user = $_POST['id_user'];
$name = $_POST['name'];
$phone_number = $_POST['phone_number'];
$description = $_POST['description'];
$user_type_id = $_POST['user_type'];

$sql = "UPDATE users SET name = ?, phone_number = ?, description = ?, user_type = ? WHERE id_user = ?";

if ($stmt = $mysqli->prepare($sql)) {

    // echo $id;
    // Bind variables to the prepared statement as parameters
    $stmt->bind_param("sssii", $name, $phone_number, $description, $user_type_id, $id_user);

    // Set parameters
    $param_name = $name;
    $param_phone_number = $phone_number;
    $param_description = $description;
    $param_user_type_id = $user_type_id;
    $param_id_user = $id_user;

    if ($stmt->execute()) {
        echo $mysqli->error;
    } else {
        echo "Oops! Something went wrong. Please try again later.";
    }
    $stmt->close();
} else {
    echo "ERRO";
}
