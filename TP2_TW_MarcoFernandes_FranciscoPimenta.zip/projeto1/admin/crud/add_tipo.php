<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate letra
    if (empty(trim($_POST['tipo']))) {
        $errors['login'] = "Introduza um tipo.";
    } else
        $tipo = trim($_POST['tipo']);

    if (empty(trim($_POST['id_type']))) {
         $errors['login'] = "Introduza um tipo.";
    } else
        $id_type = trim($_POST['id_type']);

    if (empty($errors['login'])) {
        $sql = "INSERT INTO user_types (id_type, type) VALUES (?, ?)";
        if ($stmt = $mysqli->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $param_id_type = $id_type;
            $param_tipo = $tipo;

            $stmt->bind_param("ss", $param_id_type, $param_tipo);
            // Set parameters

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Redirect to login page
                write_log("A tipo <b>" . $tipo . "</b> foi criada!");
                echo '<div style="display:block; margin-top:10px;" class="alert alert-success  alert-dismissible fade show" id="insert_alert" role="alert">
                <strong> <i class="fa-solid fa-check"></i> Tipo adicionado. </strong>
                <!-- <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button> -->
                    </div>
                    <script>
                    document.getElementById("insert_alert").style.display = "block";
                                            setTimeout(function() {
                                                $("#insert_alert").hide();
                                            }, 4000);
                                            </script>
                    ';
            } else {
                echo '<div style="display:block; margin-top:10px;" class="alert alert-danger  alert-dismissible fade show" id="insert_error" role="alert">
                <strong> <i class="fa-solid fa-triangle-exclamation"></i> Tipo não inserido. </strong>
                <!-- <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button> -->
                    </div>
                    <script>
                    document.getElementById("insert_error").style.display = "block";
                                            setTimeout(function() {
                                                $("#insert_error").hide();
                                            }, 4000);
                                            </script>
                    ';
            }
            // Close statement
            $stmt->close();
        }
    } else {
        echo '<div style="display:block; margin-top:10px;" class="alert alert-danger  alert-dismissible fade show" id="insert_error" role="alert">
                <strong> <i class="fa-solid fa-triangle-exclamation"></i> Tipo não inserido! Campos Incorretos. </strong>
                <!-- <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button> -->
                    </div>
                    <script>
                    document.getElementById("insert_error").style.display = "block";
                                            setTimeout(function() {
                                                $("#insert_error").hide();
                                            }, 4000);
                                            </script>
                    ';
    }
    // Close connection
    // $mysqli->close();
}
