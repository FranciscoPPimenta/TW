<?php
require_once "../../database/session.php";
require_once "../../database/config.php";
 
// Processing form data when form is submitted
if(isset($_SESSION["id_user"]) && !empty($_SESSION["id_user"])){

    $id_user = $_SESSION["id_user"];
    
    // Validate telefone
    $input_telefone = $_POST["telefone"];
    if(empty($input_telefone)){
        $errors['login'] = "Introduza uma telefone.";
    } else{
        $telefone = $input_telefone;
    }

    // Validate description
    $input_description = $_POST["description"];
    if(empty($input_description)){
        $errors['login'] = "Introduza uma descrição.";
    } else{
        $description = $input_description;
    }
    
    // Check input errors before inserting in database
    if(empty($errors['login'])){
        // Prepare an update statement
        $sql = "UPDATE users SET phone_number=?, description=? WHERE id_user=?";
 
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("ssi", $param_telefone, $param_description, $param_id);
            
            // Set parameters
            $param_telefone = $telefone;
            $param_description = $description;
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Records updated successfully. Redirect to landing page
                echo '<script> alert("Data Updated"); </script>';
                write_log( "Dados da conta atualizados! -> <b>" . $_SESSION["email"] . "</b>");
                header("location: ../profile.php");
                // exit();
            } else{
                echo '<script> alert("Data Not Updated"); </script>';
            }
        }
         
        // Close statement
        $stmt->close();
    }
    
    // Close connection
    $mysqli->close();
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id_user"]) && !empty(trim($_GET["id_user"]))){
        // Get URL parameter
        $id =  trim($_GET["id_user"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM users WHERE id_user = ?";
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("i", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                $result = $stmt->get_result();
                
                if($result->num_rows == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $row = $result->fetch_array(MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $email = $row["email"];
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        $stmt->close();
        
        // Close connection
        $mysqli->close();
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>