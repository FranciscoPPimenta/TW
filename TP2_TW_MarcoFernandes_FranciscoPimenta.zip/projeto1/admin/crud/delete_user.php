<?php

require ("../../database/config.php");


$dados['id'] = isset($_POST['id']) ? intval($_POST['id']) : 0;
$dados['status'] = !!$dados['id'];
$dados['msg'] = 'ID do utilizador inválido ou não indicado';

if ($dados['status']) {

    /* Attempt MySQL server connection. */
    $mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

    // Check connection
    if ($mysqli === false) {
        $dados['status'] = false;
        $dados['msg'] = 'Erro de conexão a BD. ' . $mysqli->error;
    }

    $sql = sprintf("SELECT * FROM users WHERE id_user='%s' LIMIT 1", $dados['id']);

    if ($result = $mysqli->query($sql)) {

        if ($result->num_rows > 0) {
            $sql = sprintf("DELETE FROM users WHERE id_user='%s'", $dados['id']);
            $mysqli->query($sql);
            //$dados['error'] = $mysqli->error;
            $dados['msg'] = sprintf("Utilizador com ID=%s removido.", $dados['id']);
            $result->free();
        } else {
            $dados['status'] = false;
            $dados['msg'] = sprintf("Utilizador com ID=%s inexistente.", $dados['id']);
        }
    }

    // Close connection
    $mysqli->close();
}


echo json_encode($dados);

?>
