<?php
require_once "../database/session.php";
require_once '../admin/profileSearch.php';
$isPressed = false;
$errors = "";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>CromoCruzado</title>
    <link rel="icon" type="image/x-icon" href="..\img\160logo_tw.png">
    <!-- Favicon-->
    <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="../css/styles.css" rel="stylesheet" />
    <meta name="google-signin-client_id"
        content="728139774243-4329ei6kun5qj9sbuo94kktbea7s92oc.apps.googleusercontent.com">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <script src="https://kit.fontawesome.com/4ba30dd618.js" crossorigin="anonymous"></script>
    <!-- Custom styles for this template-->
    <link href="../admin/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../admin/css/sb-admin-2.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand-lg navbar-light bg-light">
                    <div class="container px-4 px-lg-5">
                        <a class="navbar-brand" href="index.php">CromoCruzado</a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation"><span
                                class="navbar-toggler-icon"></span></button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                                <li class="nav-item"><a class="nav-link active" aria-current="page"
                                        href="index.php">Ínicio</a></li>
                                <li class="nav-item"><a class="nav-link" href="about.html">Sobre</a></li>

                            </ul>
                            <form class="d-flex">
                                <a href="carrinho.php?id=<?php echo $_SESSION["id_user"] ?>"
                                    class="btn btn-outline-dark" type="submit">
                                    <i class="bi-cart-fill me-1"></i>
                                    Carrinho
                                    <span class="badge bg-dark text-white ms-1 rounded-pill">0</span>
                                </a>
                                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                                    <li class="nav-item">
                                        <a class="nav-link"
                                            href="profile.php?id=<?php echo $_SESSION["id_user"] ?>">Profile</a>
                                    </li>
                                </ul>
                                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                                    <li class="nav-item">
                                        <a class="nav-link" href="../admin/logout.php">Logout
                                            (<?php echo $_SESSION["name"] ?>)</a>
                                    </li>
                                </ul>
                            </form>
                        </div>
                    </div>
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Profile</h1>
                    </div>



                    <div class="row">
                        <div class="col-lg-2">
                            <!-- Single Advisor-->
                            <!-- <div class="col-12 col-sm-6 col-lg-3"> -->
                            <div class="single_advisor_profile wow fadeInUp" data-wow-delay="0.2s"
                                style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                                <!-- Team Thumb-->
                                <div class="advisor_thumb" style="margin:0; padding:0"><img src="../assets/img/<?php
                                echo $profile_pic;
                                ?>" alt="<?php echo $profile_pic ?>" style="width:100%">
                                </div>
                                <!-- Team Details-->
                                <div class="single_advisor_details_info">
                                    <h6><?php echo $_SESSION["name"]; ?></h6>
                                    <p class="designation"><?php echo $_SESSION["tipo"]; ?></p>
                                </div>
                            </div>
                            <!-- </div> -->
                        </div>
                        <div class="col-lg-8">
                            <div class="card mb-4">
                                <div class="card-body">
                                    <form method="POST" id="myFormUpdate" action="update_profile.php">
                                        <div class="update">
                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <p class="mb-0">Email</p>
                                                </div>
                                                <div class="col-sm-9">
                                                    <p class="text-muted mb-0"><?php
                                                    echo $_SESSION['email'];
                                                    ?></p>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <p class="mb-0">Telefone</p>
                                                </div>
                                                <div class="col-sm-9">
                                                    <p class="text-muted mb-0"><?php
                                                    echo $telefone;
                                                    ?></p>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <p class="mb-0">Email</p>
                                                </div>
                                                <div class="col-sm-9">
                                                    <p class="text-muted mb-0"><?php
                                                    echo $description
                                                        ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <button onclick="openForm()" id="add_formAdd" style="margin-top: 30px;"
                                        class="btn btn-secondary" type="submit" value="Mudar Password">Mudar
                                        Password</button>
                                    <a href="../admin/logs.php" style="margin-top: 30px;" class="btn btn-secondary"
                                        type="submit" value="Mudar Password">Activity Log</a>
                                    <div class="container">
                                        <div class="row">
                                            <div class="" style="padding:20px;">

                                                <form method="POST" style="display:none" id="myForm"
                                                    action="change_password.php">
                                                    <div class="form-group">
                                                        <label for="old">Password Antiga:</label>
                                                        <input type="password" name="old" id="old" class="form-control"
                                                            value="<?php echo (isset($_SESSION['old'])) ? $_SESSION['old'] : ''; ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="new">Nova password:</label>
                                                        <input type="password" minlength="6" name="new" id="new"
                                                            class="form-control"
                                                            value="<?php echo (isset($_SESSION['new'])) ? $_SESSION['new'] : ''; ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="retype">Introduza novamente a password nova:</label>
                                                        <input type="password" minlength="6" name="retype" id="retype"
                                                            class="form-control"
                                                            value="<?php echo (isset($_SESSION['retype'])) ? $_SESSION['retype'] : ''; ?>">
                                                    </div>
                                                    <button type="submit" name="update" class="btn btn-success"><span
                                                            class="glyphicon glyphicon-check"></span>Atualizar</button>
                                                    <button type="button" onclick="closeForm()" class="btn btn-danger"
                                                        value="Fechar">Fechar</button>


                                                </form>
                                                <?php
                                                if (isset($_SESSION['error'])) {
                                                    ?>
                                                    <div class="alert alert-danger text-center" style="margin-top:20px;">
                                                        <?php echo $_SESSION['error']; ?>
                                                    </div>
                                                    <?php

                                                    unset($_SESSION['error']);
                                                }
                                                if (isset($_SESSION['success'])) {
                                                    ?>
                                                    <div class="alert alert-success text-center" style="margin-top:20px;">
                                                        <?php echo $_SESSION['success']; ?>
                                                    </div>
                                                    <?php

                                                    unset($_SESSION['success']);
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Cromocruzado 2024</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

    <script>
        function openForm() {
            document.getElementById("myForm").style.display = "block";
            document.getElementById("add_formAdd").style.display = "none";
        }

        function closeForm() {
            document.getElementById("add_formAdd").style.display = "block";
            document.getElementById("myForm").style.display = "none";
        }
    </script>
    <script>
        function openFormUpdate() {
            document.getElementsByClassName("input").disabled = false;
            document.getElementById("add_formAddUpdate").style.display = "none";
            $isPressed = true;
        }

        function closeFormUpdate() {
            document.getElementById("add_formAddUpdate").style.display = "block";
            document.getElementsByClassName("input").disabled = true;
            $isPressed = false;
        }
    </script>

</body>

</html>