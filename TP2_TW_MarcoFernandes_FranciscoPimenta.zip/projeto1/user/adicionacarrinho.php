<?php
require_once '../database/config.php';
require_once '../database/session.php';
$sticker = $_POST["id"];
$qtd = $_POST["quantia"];
$sql = 'SELECT * FROM carrinho WHERE user = ' . $_SESSION["id_user"] . ' AND sticker = ' . $sticker;
if ($stmt = $mysqli->prepare($sql)) {
    if ($stmt->execute()) {
        $stmt->store_result();
        if ($stmt->num_rows == 1) {
            echo '2';
            // Get the result
            $result = $stmt->get_result();
            // Fetch the type from the result
            if ($row = $result->fetch_assoc()) {
                $type = $row['quantia'];
                echo '3';
            } else {
                $type = null; // or handle the case when no type is found
                echo 'null';
            }
            $quantia = $qtd + $type;
            $stmt->close();
            $sql = 'UPDATE carrinho SET quantia = ' . $quantia . ' WHERE user =' . $_SESSION["id_user"];
            if ($stmt = $mysqli->prepare($sql)) {
                $stmt->execute();
                echo '5';
            }
            echo '4';
        } else {
            $stmt->close();
            $sql = 'INSERT INTO carrinho (user, sticker,quantia) VALUES (' . $_SESSION["id_user"] . ',' . $sticker . ',' . $qtd . ')';
            if ($stmt = $mysqli->prepare($sql)) {
                $stmt->execute();
                echo '5';
                header("location: view.php?id=" . $sticker);
            }
        }
    }

    $stmt->close();


}

?>