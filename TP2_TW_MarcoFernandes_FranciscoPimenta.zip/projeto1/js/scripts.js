/*!
* Start Bootstrap - Shop Homepage v5.0.6 (https://startbootstrap.com/template/shop-homepage)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-shop-homepage/blob/master/LICENSE)
*/
// This file is intentionally blank
// Use this file to add JavaScript to your project
// Exemplo de dados simulados de contas
// Função para fazer login

async function fazerLogin(email, senha) {
    try {
      // Carrega os dados das contas do arquivo JSON
      const resposta = await fetch('../js/dados.json');
      const contas = await resposta.json();
  
      // Verifica se o email e senha correspondem a alguma conta
      const contaEncontrada = contas.find(conta => conta.email === email && conta.password === senha);
      
      if (contaEncontrada) {
        console.log("Login bem-sucedido!");
        location.href = "index.html";
        return true;
      } else {
        console.log("Email ou senha incorretos. Tente novamente.");
        return false;
      }
    } catch (erro) {
      console.error("Erro ao carregar dados das contas:", erro);
      return false;
    }
}

function prepararLogin(){
    const email = document.getElementById('exampleInputEmail').value;
    const password = document.getElementById('exampleInputPassword').value;
    console.log(email);
    console.log(password);
  
    fazerLogin(email, password);
}
  
  // Exemplo de uso do script
  // const email = prompt("Digite o seu email:");
  // const senha = prompt("Digite a sua senha:");
  
  // fazerLogin(email, senha);
  
  function onSignIn(googleUser) {
    console.log("google");
    var profile = googleUser.getBasicProfile();
    console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
    console.log('Name: ' + profile.getName());
    console.log('Image URL: ' + profile.getImageUrl());
    console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.
  }