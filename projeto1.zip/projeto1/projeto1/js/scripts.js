/*!
* Start Bootstrap - Shop Homepage v5.0.6 (https://startbootstrap.com/template/shop-homepage)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-shop-homepage/blob/master/LICENSE)
*/
// This file is intentionally blank
// Use this file to add JavaScript to your project
// Exemplo de dados simulados de contas
// Função para fazer login

async function fazerLogin(email, senha) {
    try {
      // Carrega os dados das contas do arquivo JSON
      const resposta = await fetch('../js/dados.json');
      const contas = await resposta.json();
  
      // Verifica se o email e senha correspondem a alguma conta
      const contaEncontrada = contas.find(conta => conta.email === email && conta.password === senha);
      
      if (contaEncontrada) {
        alert("Login bem-sucedido!");
        location.href = "index.html";
        return true;
      } else {
        alert("Email ou senha incorretos. Tente novamente.");
        return false;
      }
    } catch (erro) {
      alert("Erro ao carregar dados das contas:", erro);
      return false;
    }
}

function prepararLogin(){
    const email = document.getElementById('exampleInputEmail').value;
    const password = document.getElementById('exampleInputPassword').value;
    console.log(email);
    console.log(password);
  
    fazerLogin(email, password);
}

function alerta(status){
  if(status == "registo"){
    alert("Criado com sucesso");
  }else if(status == "password"){
    alert("Password alterado com sucesso.")
  }

} 
  
function apiCromos(){
  var textoCard = "";
  var textInCard = "";
  $.ajax({
      url:"https://run.mocky.io/v3/7bf1f537-f35f-4736-ad11-589de988d3ae",
      method: "GET",
      success: function(data){
          const pais = data.Country;
          pais.forEach(element => {
              console.log(element);
              textoCard = `<div class="container px-4 px-lg-5 mt-5" style="text-align: center">
                          <h1 style="padding-bottom: 20px">${element.name}</h1>
                          <div id="card${element.name}" class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center\"></div>
                      </div>`;
              document.getElementById("cromos").innerHTML+=textoCard;
              for(let i = 0;i < element.players.length;i++){
                  textInCard = `
              <div class="col mb-5">
                  <div class="card h-100">
                  <!-- Product image-->
                  <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..." />
                  <!-- Product details-->
                      <div class="card-body p-4">
                      <div class="text-center">
                              <!-- Product name-->
                              <h5 class="fw-bolder">${element.players[i].name}</h5>
                              <!-- Product price-->$40.00 - $80.00
                          </div>
                      </div>
                      <!-- Product actions-->
                      <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                          <div class="text-center">
                              <a class="btn btn-outline-dark mt-auto" href="view.html?id=${element.players[i].id}" >Ver detalhes</a>
                          </div>
                      </div>
                  </div>
              </div>`;
                  document.getElementById("card"+element.name).innerHTML+=textInCard;
                  }
              });
      }
  })
}

function apiCromosDetalhes() {
  var textInCard = "";
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get('id');
  let idSemPlicas = id.replace(/'/g, '');
  $.ajax({
    url: "https://run.mocky.io/v3/7bf1f537-f35f-4736-ad11-589de988d3ae",
    method: "GET",
    success: function (data) {
      const pais = data.Country;
      pais.forEach(element => {
        //console.log(element);
        element.players.forEach(player => {
          if (player.id == idSemPlicas) {
            textInCard = `
              <div class="container px-4 px-lg-5 my-5">
                <div class="row gx-4 gx-lg-5 align-items-center">
                  <div class="col-md-6"><img class="card-img-top mb-5 mb-md-0" src="https://dummyimage.com/600x700/dee2e6/6c757d.jpg" alt="..." /></div>
                  <div class="col-md-6">
                    <div class="small mb-1">SKU: BST-498</div>
                    <h1 class="display-5 fw-bolder">${player.name}</h1>
                    <div class="fs-5 mb-5">
                      <span class="text-decoration-line-through">$45.00</span>
                      <span>$40.00</span>
                    </div>
                    <p class="lead">
                      <b>Posição:</b> ${player.position}
                      <br><br>
                      <b>Clube:</b> ${player.club}
                      <br><br>
                    </p>
                    <div class="d-flex">
                      <input class="form-control text-center me-3" id="inputQuantity" type="num" value="1" style="max-width: 3rem" />
                      <button class="btn btn-outline-dark flex-shrink-0" type="button">
                        <i class="bi-cart-fill me-1"></i>
                        Adicionar ao carrinho
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            `;
            document.getElementById("apiCromosDetalhes").innerHTML = textInCard;
          }
        });
      });
    }
  });
}

function randomQuote(){
  var text="";
  $.ajax({
      method: 'GET',
      url: 'https://api.quotable.io/random',
      contentType: 'application/json',
      success: function(result) {
        text=`
        <h3>'${result.content}'</h3><p><i> - ${result.author}</p></i>
        `;
        document.getElementById("quote").innerHTML = text;
      },
  });
}
  