<?php
require_once '../database/config.php';
require_once '../database/session.php';
$sql = "SELECT * FROM stickers ";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>CromoCruzado</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="../css/styles.css" rel="stylesheet" />
    <meta name="google-signin-client_id"
        content="728139774243-4329ei6kun5qj9sbuo94kktbea7s92oc.apps.googleusercontent.com">
</head>

<body>
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="index.php">CromoCruzado</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <li class="nav-item"><a class="nav-link active" aria-current="page" href="index.php">Ínicio</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.html">Sobre</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">Loja</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#!">Todos os Cromos</a></li>
                            <li>
                                <hr class="dropdown-divider" />
                            </li>
                            <li><a class="dropdown-item" href="#!">Cromos Populares</a></li>
                            <li><a class="dropdown-item" href="#!">Novos Cromos</a></li>
                        </ul>
                    </li>
                </ul>
                <form class="d-flex">
                    <a href="carrinho.php?id=<?php echo $_SESSION["id_user"] ?>" class="btn btn-outline-dark">
                        <i class="bi-cart-fill me-1"></i>
                        Carrinho
                        <span class="badge bg-dark text-white ms-1 rounded-pill">0</span>
                    </a>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php?id=<?php echo $_SESSION["id_user"] ?>">Profile</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item">
                            <a class="nav-link" href="../admin/logout.php">Logout (<?php echo $_SESSION["name"] ?>)</a>
                        </li>
                    </ul>
                </form>
            </div>
        </div>
    </nav>
    <!-- Header-->
    <header class="bg-dark py-5">
        <div class="container px-4 px-lg-5 my-5">
            <div class="text-center text-white">
                <h1 class="display-4 fw-bolder">Compra/Venda/Troca com estilo</h1>
                <p class="lead fw-normal text-white-50 mb-0">Completa a tua coleção!</p>
            </div>
        </div>
    </header>
    <!-- Section-->
    <section class="py-5">
        <div class="container px-4 px-lg-5 mt-5">
            <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <?php

                if ($stmt = $mysqli->prepare($sql)) {
                    if ($stmt->execute()) {
                        $stmt->store_result();
                        $stmt->execute();
                        $stickers = $stmt->get_result();
                        foreach ($stickers as $sticker) {
                            echo '<div class="col mb-5">
                                    <div class="card h-100">
                                        <!-- Product image-->
                                        <img class="card-img-top" style="width:450;height:300px" src="../img/' . $sticker["sticker_pic"] . '" alt="' . $sticker["sticker_pic"] . '" />
                                        <!-- Product details-->
                                        <div class="card-body p-4">
                                            <div class="text-center">
                                                <!-- Product name-->
                                                <h5 class="fw-bolder">' . $sticker["sticker_name"] . '</h5>
                                                <!-- Product price-->
                                                ' . $sticker["sticker_price"] . ' €
                                            </div>
                                        </div>
                                        <!-- Product actions-->
                                        <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                            <div class="text-center"><a id="' . $sticker["id_sticker"] . '"class="btn btn-outline-dark mt-auto" href="view.php?id=' . $sticker["id_sticker"] . '&&nome=' . $sticker["sticker_name"] . '">More
                                                    info</a></div>
                                        </div>
                                    </div>
                                </div>
                            ';
                        }
                    }
                }
                ?>
            </div>
        </div>
    </section>
    <!-- Footer-->
    <footer class="py-5 bg-dark">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; CromoCruzado 2024</p>
        </div>
    </footer>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
    <!-- Google Platform Library -->
    <script src="https://apis.google.com/js/platform.js" async defer></script>
</body>

</html>