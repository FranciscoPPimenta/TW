<?php
require_once '../database/config.php';
require_once '../database/session.php';
$id_user = $_SESSION['id_user'];
$description = $telefone = $profile_pic = "";
$sql = "SELECT * FROM users WHERE id_user = $id_user";
if ($result = $mysqli->query($sql)) {
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_array()) {
            $description = $row['description'];
            $telefone = $row['phone_number'];
            $profile_pic = $row['profile_pic'];
        }
        $result->free();
    } else {
        echo "No records matching your query were found.";
    }
} else {
    echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
}
// Close connection
$mysqli->close();
?>
