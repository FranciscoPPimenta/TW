(function($) {
  "use strict"; // Start of use strict

  // Toggle the side navigation
  $("#sidebarToggle, #sidebarToggleTop").on('click', function(e) {
    $("body").toggleClass("sidebar-toggled");
    $(".sidebar").toggleClass("toggled");
    if ($(".sidebar").hasClass("toggled")) {
      $('.sidebar .collapse').collapse('hide');
    };
  });

  // Close any open menu accordions when window is resized below 768px
  $(window).resize(function() {
    if ($(window).width() < 768) {
      $('.sidebar .collapse').collapse('hide');
    };
    
    // Toggle the side navigation when window is resized below 480px
    if ($(window).width() < 480 && !$(".sidebar").hasClass("toggled")) {
      $("body").addClass("sidebar-toggled");
      $(".sidebar").addClass("toggled");
      $('.sidebar .collapse').collapse('hide');
    };
  });

  // Prevent the content wrapper from scrolling when the fixed side navigation hovered over
  $('body.fixed-nav .sidebar').on('mousewheel DOMMouseScroll wheel', function(e) {
    if ($(window).width() > 768) {
      var e0 = e.originalEvent,
        delta = e0.wheelDelta || -e0.detail;
      this.scrollTop += (delta < 0 ? 1 : -1) * 30;
      e.preventDefault();
    }
  });

  // Scroll to top button appear
  $(document).on('scroll', function() {
    var scrollDistance = $(this).scrollTop();
    if (scrollDistance > 100) {
      $('.scroll-to-top').fadeIn();
    } else {
      $('.scroll-to-top').fadeOut();
    }
  });

  // Smooth scrolling using jQuery easing
  $(document).on('click', 'a.scroll-to-top', function(e) {
    var $anchor = $(this);
    $('html, body').stop().animate({
      scrollTop: ($($anchor.attr('href')).offset().top)
    }, 1000, 'easeInOutExpo');
    e.preventDefault();
  });

})(jQuery); // End of use strict

function apiCromos(){
  var textoCard = "";
  var textInCard = "";
  $.ajax({
      url:"https://run.mocky.io/v3/7bf1f537-f35f-4736-ad11-589de988d3ae",
      method: "GET",
      success: function(data){
          const pais = data.Country;
          pais.forEach(element => {
              console.log(element);
              textoCard = `<div class="container px-4 px-lg-5 mt-5">
                          ${element.name}
                          <div id="card${element.name}" class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center\"></div>
                      </div>`;
              document.getElementById("cromos").innerHTML+=textoCard;
              for(let i = 0;i < element.players.length;i++){
                  textInCard = `
              <div class="col mb-5">
                  <div class="card h-100">
                  <!-- Product image-->
                  <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..." />
                  <!-- Product details-->
                      <div class="card-body p-4">
                      <div class="text-center">
                              <!-- Product name-->
                              <h5 class="fw-bolder">${element.players[i].name}</h5>
                              <!-- Product price-->$40.00 - $80.00
                          </div>
                      </div>
                      <!-- Product actions-->
                      <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                          <div class="text-center">
                              <a class="btn btn-outline-dark mt-auto" onclick="viewEdit();">Edit</a>
                              <a class="btn btn-outline-dark mt-auto" onclick="viewDeleted();">Delete</a>
                              <div id="myModal" class="modal">
                                  <!-- Modal content -->
                                  <div class="modal-content">
                                      <div class="modal-header">
                                      <span class="close">&times;</span>
                                      <h2>Modal Header</h2>
                                      </div>
                                      <div class="modal-body">
                                      <p>Some text in the Modal Body</p>
                                      <p>Some other text...</p>
                                      <p id="quote"></p>
                                      </div>
                                      <div class="modal-footer">
                                      <h3>Modal Footer</h3>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>`;
                  document.getElementById("card"+element.name).innerHTML+=textInCard;
                  }
              });
      }
  })
}

function viewEdit(){
    alert("Cromo Editado com sucesso!");
}

function viewDeleted(){
  alert("Cromo Apagado com sucesso!");
}