<?php
require_once '../../database/session.php';
require '../../database/config.php';

$sql = "SELECT DISTINCT id_type, type FROM user_types";
$result = $mysqli->query($sql);
if ($result->num_rows > 0) {
    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
}else{       
    echo "No records matching your query were found.";
}