<?php
require_once "../../database/session.php";
require_once "../../database/config.php";
 


// Processing form data when form is submitted
if(isset($_SESSION["id_user"]) && !empty($_SESSION["id_user"])){

    $id_user = $_SESSION["id_user"];
    
    // Validate disciplina
    $input_disciplina = $_POST["disciplina"];
    if(empty($input_disciplina)){
        $errors['login'] = "Introduza uma disciplina.";
    } else{
        $disciplina = $input_disciplina;
    }
    
    // Check input errors before inserting in database
    if(empty($errors['login'])){
        // Prepare an update statement
        $sql = "UPDATE disciplina SET disciplina=? WHERE id=?";
 
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("si", $param_disciplina, $param_id);
            
            // Set parameters
            $param_disciplina = $disciplina;
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Records updated successfully. Redirect to landing page
                echo '<script> alert("Data Updated"); </script>';
                write_log( "Disciplina atualizada! -> <b>" . $disciplina . "</b>");
                header("location: ../criardisciplina.php");
                // exit();
            } else{
                echo '<script> alert("Data Not Updated"); </script>';
            }
        }
         
        // Close statement
        $stmt->close();
    }
    
    // Close connection
    $mysqli->close();
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM disciplina WHERE id = ?";
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("i", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                $result = $stmt->get_result();
                
                if($result->num_rows == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $row = $result->fetch_array(MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $disciplina = $row["disciplina"];
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        $stmt->close();
        
        // Close connection
        $mysqli->close();
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>