<?php
require_once '../../database/session.php';
// Process delete operation after confirmation
if(isset($_POST["id_type"]) && !empty($_POST["id_type"])){
    // Include config file
    require_once "../../database/config.php";
    $old_tipo = $_POST["id_type"];
    // Prepare a delete statement
    $sql = "DELETE FROM user_types WHERE id_type = ?";
    
    if($stmt = $mysqli->prepare($sql)){
        // Bind variables to the prepared statement as parameters
        $stmt->bind_param("i", $param_id);
        
        // Set parameters
        $param_id = trim($_POST["id_type"]);
        
        // Attempt to execute the prepared statement
        if($stmt->execute()){
            // Records deleted successfully. Redirect to landing page
            write_log( "O tipo com o ID: <b>" . $old_tipo . "</b> foi eliminado!");
            header("location: ../type.php");
            exit();
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    $stmt->close();
    
    // // Close connection
    $mysqli->close();
} else{
    // Check existence of id parameter
    if(empty(trim($_GET["id_type"]))){
        // URL doesn't contain id parameter. Redirect to error page
        header("location: ../404.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Eliminar Tipo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5 mb-3">Eliminar Tipo</h2>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="alert alert-danger">
                            <input type="hidden" name="id_type" value="<?php echo trim($_GET["id_type"]); ?>"/>
                            <p>Tem a certeza que pretende eliminar este tipo?</p>
                            <p>
                                <input type="submit" value="Sim" class="btn btn-danger">
                                <a href="../type.php" class="btn btn-secondary ml-2">Não</a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>